/*
 * 1) Copy the javascript below and save as a bookmarklet in a browser to view jQuery Mobile page event logs.
 * https://github.com/jquery/jquery-mobile/blob/master/tools/log-page-events.html
 */
javascript:function%20loadScript(u)%7Bvar%20s=document.createElement('script');s.setAttribute('language','javascript');s.setAttribute('src',u);document.body.appendChild(s);%7D%20loadScript('https://raw.github.com/jquery/jquery-mobile/master/tools/log-page-events.js');