<!DOCTYPE html>
<html>
	<head>
	<title>IBM JQuery Tutorial</title>
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a3/jquery.mobile-1.0a3.min.css" />
	<script src="http://code.jquery.com/jquery-1.5.min.js"></script>
	
	<script src="http://code.jquery.com/mobile/1.0a3/jquery.mobile-1.0a3.min.js"></script>
	<script src="http://jquery.ibm.navitend.com/utils.js"></script>
	</head>
