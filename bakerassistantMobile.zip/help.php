<?php
	function showHelp(){
		print("<div>
			  <img src='images/面包师助手001.gif'>
			  <img src='images/面包师助手002.gif'>
			  <img src='images/面包师助手003.gif'>
			  </div>
			");
	}
?>